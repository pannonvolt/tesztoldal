import Link from "next/link";
import { usePathname } from "next/navigation";

import { Button } from "@/components/ui/button";
import { DialPadIcon } from "@/components/ui/icons";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Logo } from "@/components/Logo";
import { cn } from "@/lib/utils";

const ResponsiveNavbar = () => {
   const pathname = usePathname();

   return (
      <Sheet>
         <SheetTrigger asChild>
            <Button
               variant="skew"
               className="!h-[48px] !w-[48px] bg-slate-500/50 hover:bg-slate-500/60 xl:!h-[60px] xl:!w-[60px]"
               size="icon"
               aria-label="Open Menu"
            >
               <DialPadIcon className="h-5 w-5 xl:h-6 xl:w-6" />
            </Button>
         </SheetTrigger>
         <SheetContent side="right">
            <div className="grid gap-6 p-2.5 font-header md:p-4">
               <div className="w-full rounded-sm bg-background-dark px-3 py-4">
                  <Link
                     href="/"
                     className="flex items-center gap-2"
                     prefetch={false}
                  >
                     <Logo />
                  </Link>
               </div>
               <nav className="grid gap-4">
                  <Link
                     href="/"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Home
                  </Link>
                  <Link
                     href="/home2"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/home2"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Home 2
                  </Link>
                  <Link
                     href="/home3"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/home3"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Home 3
                  </Link>
                  <Link
                     href="/projects"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/projects"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Projects
                  </Link>
                  <Link
                     href="/projects/projectId"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/projects/projectId"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Project Details
                  </Link>
                  <Link
                     href="/services"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/services"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Services
                  </Link>
                  <Link
                     href="/services/serviceId"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/services/serviceId"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Service Details
                  </Link>
                  <Link
                     href="/teams"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/teams"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Teams
                  </Link>
                  <Link
                     href="/pricing"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/pricing"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Pricing
                  </Link>
                  <Link
                     href="/blogs"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/blogs"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Blogs
                  </Link>
                  <Link
                     href="/blogs/blogId"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/blogs/blogId"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Blog Details
                  </Link>
                  <Link
                     href="/faqs"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/faqs"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     FAQs
                  </Link>
                  <Link
                     href="/about"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/about"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     About
                  </Link>
                  <Link
                     href="/contact"
                     className={cn(
                        "flex items-center gap-2 text-sm font-medium transition-all duration-75 hover:text-tertiary hover:underline hover:underline-offset-4",
                        pathname === "/contact"
                           ? "text-tertiary"
                           : "text-default-black",
                     )}
                     prefetch={false}
                  >
                     Contact
                  </Link>
               </nav>
            </div>
         </SheetContent>
      </Sheet>
   );
};

export { ResponsiveNavbar };
