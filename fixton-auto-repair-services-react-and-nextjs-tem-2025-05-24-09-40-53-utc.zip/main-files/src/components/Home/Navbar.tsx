"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LuChevronDown } from "react-icons/lu";
import { motion } from "framer-motion";

import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { CartIcon, RightArrowIcon, SearchIcon } from "@/components/ui/icons";
import { cn } from "@/lib/utils";
import { ResponsiveNavbar } from "@/components/ResponsiveNavbar";
import {
   HoverCard,
   HoverCardContent,
   HoverCardTrigger,
} from "@/components/ui/hover-card";
import { MotionLogo } from "@/components/animations/motion";

interface NavbarProps {
   isFixed?: boolean;
}

export const onscreen = { opacity: 1, y: 0, transition: { duration: 0.5 } };

const Navbar = ({ isFixed }: NavbarProps) => {
   const pathname = usePathname();

   return (
      <motion.nav
         initial="offscreen"
         whileInView="onscreen"
         viewport={{ once: true }}
         className={cn(
            "navbar-h z-50 flex w-full items-center justify-between bg-black/10 backdrop-blur",
            isFixed
               ? "fixed left-1/2 top-0 mx-auto -translate-x-1/2"
               : "sticky top-0",
         )}
      >
         <div
            className={cn(
               "container flex h-full max-w-[1720px] items-center justify-between px-5 text-default 2xl:px-0",
            )}
         >
            <div className="flex h-14 items-center gap-x-2 lg:gap-x-12 xl:gap-x-24">
               <MotionLogo
                  variants={{
                     offscreen: { opacity: 0, y: -100 },
                     onscreen,
                  }}
               />

               <div className="offscreen hidden font-header font-bold leading-4 lg:flex lg:font-extrabold">
                  <ul className="navbar-list__container flex items-center text-xs uppercase lg:gap-x-2.5 xl:gap-x-5 xl:text-sm 2xl:gap-x-10">
                     <motion.li
                        variants={{
                           offscreen: { opacity: 0, y: -100 },
                           onscreen: {
                              opacity: 1,
                              y: 0,
                              transition: {
                                 duration: 0.5,
                                 delay: 0.1,
                                 bounce: 0.25,
                                 type: "spring",
                              },
                           },
                        }}
                        className={cn({
                           "navbar2-active__1": pathname === "/",
                        })}
                     >
                        <HoverCard openDelay={20} closeDelay={10}>
                           <HoverCardTrigger asChild>
                              <Link
                                 href="/"
                                 style={{ display: "flex", gap: "3px" }}
                              >
                                 <span>home</span>
                                 <LuChevronDown className="size-4" />
                              </Link>
                           </HoverCardTrigger>
                           <HoverCardContent
                              className={cn(
                                 "z-50 mt-1.5 w-32 rounded-sm border-primary bg-black/80 text-white backdrop-blur",
                                 pathname === "/" ? "skew-x-0" : "",
                              )}
                           >
                              <div>
                                 <ul className="grid space-y-2">
                                    <li>
                                       <Link href="/">Home 1</Link>
                                    </li>
                                    <li>
                                       <Link href="/home2">Home 2</Link>
                                    </li>
                                    <li>
                                       <Link href="/home3">Home 3</Link>
                                    </li>
                                 </ul>
                              </div>
                           </HoverCardContent>
                        </HoverCard>
                     </motion.li>

                     <motion.li
                        variants={{
                           offscreen: { opacity: 0, y: -100 },
                           onscreen: {
                              opacity: 1,
                              y: 0,
                              transition: {
                                 duration: 0.5,
                                 delay: 0.15,
                                 bounce: 0.25,
                                 type: "spring",
                              },
                           },
                        }}
                        className={cn(
                           `${pathname === "/services" ? "navbar2-active__1" : ""}`,
                        )}
                     >
                        <Link href="/services">SERVICES</Link>
                     </motion.li>
                     <motion.li
                        variants={{
                           offscreen: { opacity: 0, y: -100 },
                           onscreen: {
                              opacity: 1,
                              y: 0,
                              transition: {
                                 duration: 0.5,
                                 delay: 0.2,
                                 bounce: 0.25,
                                 type: "spring",
                              },
                           },
                        }}
                        className={cn(
                           `${pathname === "/projects" ? "navbar2-active__1" : ""}`,
                        )}
                     >
                        <Link href="/projects">PROJECTS</Link>
                     </motion.li>
                     <motion.li
                        variants={{
                           offscreen: { opacity: 0, y: -100 },
                           onscreen: {
                              opacity: 1,
                              y: 0,
                              transition: {
                                 duration: 0.5,
                                 delay: 0.25,
                                 bounce: 0.25,
                                 type: "spring",
                              },
                           },
                        }}
                        className={cn(
                           `${pathname === "/pricing" ? "navbar2-active__1" : ""}`,
                        )}
                     >
                        <Link href="/pricing">pricing</Link>
                     </motion.li>
                     <motion.li
                        variants={{
                           offscreen: { opacity: 0, y: -100 },
                           onscreen: {
                              opacity: 1,
                              y: 0,
                              transition: {
                                 duration: 0.5,
                                 delay: 0.3,
                                 bounce: 0.25,
                                 type: "spring",
                              },
                           },
                        }}
                        className={cn(
                           `${pathname === "/blogs" ? "navbar2-active__1" : ""}`,
                        )}
                     >
                        <HoverCard closeDelay={10} openDelay={20}>
                           <HoverCardTrigger asChild>
                              <Link
                                 href="/blogs"
                                 style={{ display: "flex", gap: "3px" }}
                              >
                                 <span>pages</span>
                                 <LuChevronDown className="size-4" />
                              </Link>
                           </HoverCardTrigger>
                           <HoverCardContent
                              className={cn(
                                 "z-50 mt-1.5 w-auto rounded-sm border-primary bg-black/80 text-white backdrop-blur",
                              )}
                           >
                              <div>
                                 <ul className="grid space-y-2">
                                    <li>
                                       <Link href="/about">About</Link>
                                    </li>
                                    <li>
                                       <Link href="/services">Services</Link>
                                    </li>
                                    <li>
                                       <Link href="/services/serviceId">
                                          Service Details
                                       </Link>
                                    </li>
                                    <li>
                                       <Link href="/teams">Teams</Link>
                                    </li>
                                    <li>
                                       <Link href="/projects">Projects</Link>
                                    </li>
                                    <li>
                                       <Link href="/projects/projectId">
                                          Project Details
                                       </Link>
                                    </li>
                                    <li>
                                       <Link href="/pricing">Pricing</Link>
                                    </li>
                                    <li>
                                       <Link href="/faqs">FAQs</Link>
                                    </li>
                                    <li>
                                       <Link href="/blogs">Blogs</Link>
                                    </li>
                                    <li>
                                       <Link href="/blogs/blogId">
                                          Blog Details
                                       </Link>
                                    </li>
                                    <li>
                                       <Link href="/contact">Contact</Link>
                                    </li>
                                 </ul>
                              </div>
                           </HoverCardContent>
                        </HoverCard>
                     </motion.li>
                     <motion.li
                        variants={{
                           offscreen: { opacity: 0, y: -100 },
                           onscreen: {
                              opacity: 1,
                              y: 0,
                              transition: {
                                 duration: 0.5,
                                 delay: 0.35,
                                 bounce: 0.25,
                                 type: "spring",
                              },
                           },
                        }}
                        className={cn(
                           `${pathname === "/contact" ? "navbar2-active__1" : ""}`,
                        )}
                     >
                        <Link href="/contact">CONTACT</Link>
                     </motion.li>
                  </ul>
               </div>
            </div>
            <div className="flex h-14 items-center gap-x-3 text-default md:gap-x-6 lg:gap-x-8">
               <motion.div
                  variants={{
                     offscreen: { opacity: 0, y: -100 },
                     onscreen: {
                        opacity: 1,
                        y: 0,
                        transition: {
                           duration: 0.5,
                           delay: 0.4,
                           bounce: 0.25,
                           type: "spring",
                        },
                     },
                  }}
                  className="flex items-center gap-x-2 md:gap-x-4"
               >
                  <Link href="/cart">
                     <CartIcon className="h-4 w-4 fill-white md:h-6 md:w-6" />
                  </Link>
                  <Separator
                     orientation="vertical"
                     className="h-5 w-px bg-white opacity-100 md:h-6"
                  />
                  <Link href="/search">
                     <SearchIcon className="h-4 w-4 fill-white md:h-6 md:w-6" />
                  </Link>
               </motion.div>

               <motion.div
                  variants={{
                     offscreen: { opacity: 0, y: -100 },
                     onscreen: {
                        opacity: 1,
                        y: 0,
                        transition: {
                           duration: 0.5,
                           delay: 0.45,
                           bounce: 0.25,
                           type: "spring",
                        },
                     },
                  }}
                  className="flex items-center gap-x-3 font-header"
               >
                  <Button
                     variant="skewBig"
                     size="skewBig"
                     className="offscreen hidden sm:flex lg:hidden xl:mr-1.5 xl:flex"
                  >
                     <span>GET QUOTE</span>
                     <RightArrowIcon className="fill-white" />
                  </Button>

                  <ResponsiveNavbar />
               </motion.div>
            </div>
         </div>
      </motion.nav>
   );
};

export { Navbar };
