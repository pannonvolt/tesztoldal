/* eslint-disable react/prop-types */
"use client";
import * as React from "react";
import * as CheckboxPrimitive from "@radix-ui/react-checkbox";
import { LuCheck } from "react-icons/lu";

import { cn } from "@/lib/utils";

const Checkbox = React.forwardRef<
   React.ElementRef<typeof CheckboxPrimitive.Root>,
   React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root>
>(({ className, ...props }, ref) => (
   <CheckboxPrimitive.Root
      ref={ref}
      className={cn(
         "focus-visible:ring-ring peer h-[17px] w-[17px] shrink-0 rounded-[2px] border border-primary ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground",
         className,
      )}
      {...props}
   >
      <CheckboxPrimitive.Indicator
         className={cn("flex items-center justify-center text-current")}
      >
         <LuCheck className="h-[17px] w-[17px]" />
      </CheckboxPrimitive.Indicator>
   </CheckboxPrimitive.Root>
));
Checkbox.displayName = CheckboxPrimitive.Root.displayName;

export { Checkbox };
