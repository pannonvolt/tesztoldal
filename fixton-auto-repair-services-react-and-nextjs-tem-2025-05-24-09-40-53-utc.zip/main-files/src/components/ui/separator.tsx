"use client";
import * as React from "react";
import * as SeparatorPrimitive from "@radix-ui/react-separator";

import { cn } from "@/lib/utils";

const Separator = React.forwardRef<
   React.ElementRef<typeof SeparatorPrimitive.Root>,
   React.ComponentPropsWithoutRef<typeof SeparatorPrimitive.Root>
>(
   (
      // eslint-disable-next-line react/prop-types
      { className, orientation = "horizontal", decorative = true, ...props },
      ref,
   ) => (
      <SeparatorPrimitive.Root
         ref={ref}
         decorative={decorative}
         orientation={orientation}
         className={cn(
            "bg-border shrink-0 bg-[#d9d9d9] opacity-30",
            orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]",
            className,
         )}
         {...props}
      />
   ),
);
Separator.displayName = SeparatorPrimitive.Root.displayName;

export { Separator };
