/* eslint-disable react/prop-types */
"use client";
import * as React from "react";
import useEmblaCarousel, {
   type UseEmblaCarouselType,
} from "embla-carousel-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { LeftArrow2Icon, RightArrow2Icon } from "./icons";

type CarouselApi = UseEmblaCarouselType[1];
type UseCarouselParameters = Parameters<typeof useEmblaCarousel>;
type CarouselOptions = UseCarouselParameters[0];
type CarouselPlugin = UseCarouselParameters[1];

type CarouselProps = {
   opts?: CarouselOptions;
   plugins?: CarouselPlugin;
   orientation?: "horizontal" | "vertical";
   setApi?: (api: CarouselApi) => void;
};

type CarouselContextProps = {
   carouselRef: ReturnType<typeof useEmblaCarousel>[0];
   api: ReturnType<typeof useEmblaCarousel>[1];
   scrollPrev: () => void;
   scrollNext: () => void;
   canScrollPrev: boolean;
   canScrollNext: boolean;
} & CarouselProps;

const CarouselContext = React.createContext<CarouselContextProps | null>(null);

function useCarousel() {
   const context = React.useContext(CarouselContext);

   if (!context) {
      throw new Error("useCarousel must be used within a <Carousel />");
   }

   return context;
}

const Carousel = React.forwardRef<
   HTMLDivElement,
   React.HTMLAttributes<HTMLDivElement> & CarouselProps
>(
   (
      {
         orientation = "horizontal",
         opts,
         setApi,
         plugins,
         className,
         children,
         ...props
      },
      ref,
   ) => {
      const [carouselRef, api] = useEmblaCarousel(
         {
            ...opts,
            axis: orientation === "horizontal" ? "x" : "y",
         },
         plugins,
      );
      const [canScrollPrev, setCanScrollPrev] = React.useState(false);
      const [canScrollNext, setCanScrollNext] = React.useState(false);

      const onSelect = React.useCallback((api: CarouselApi) => {
         if (!api) {
            return;
         }

         setCanScrollPrev(api.canScrollPrev());
         setCanScrollNext(api.canScrollNext());
      }, []);

      const scrollPrev = React.useCallback(() => {
         api?.scrollPrev();
      }, [api]);

      const scrollNext = React.useCallback(() => {
         api?.scrollNext();
      }, [api]);

      const handleKeyDown = React.useCallback(
         (event: React.KeyboardEvent<HTMLDivElement>) => {
            if (event.key === "ArrowLeft") {
               event.preventDefault();
               scrollPrev();
            } else if (event.key === "ArrowRight") {
               event.preventDefault();
               scrollNext();
            }
         },
         [scrollPrev, scrollNext],
      );

      React.useEffect(() => {
         if (!api || !setApi) {
            return;
         }

         setApi(api);
      }, [api, setApi]);

      React.useEffect(() => {
         if (!api) {
            return;
         }

         onSelect(api);
         api.on("reInit", onSelect);
         api.on("select", onSelect);

         return () => {
            api?.off("select", onSelect);
         };
      }, [api, onSelect]);

      return (
         <CarouselContext.Provider
            value={{
               carouselRef,
               api: api,
               opts,
               orientation:
                  orientation ||
                  (opts?.axis === "y" ? "vertical" : "horizontal"),
               scrollPrev,
               scrollNext,
               canScrollPrev,
               canScrollNext,
            }}
         >
            <div
               ref={ref}
               onKeyDownCapture={handleKeyDown}
               className={cn("relative", className)}
               role="region"
               aria-roledescription="carousel"
               {...props}
            >
               {children}
            </div>
         </CarouselContext.Provider>
      );
   },
);
Carousel.displayName = "Carousel";

const CarouselContent = React.forwardRef<
   HTMLDivElement,
   React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
   const { carouselRef, orientation } = useCarousel();

   return (
      <div ref={carouselRef} className="overflow-hidden">
         <div
            ref={ref}
            className={cn(
               "flex",
               orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col",
               className,
            )}
            {...props}
         />
      </div>
   );
});
CarouselContent.displayName = "CarouselContent";

const CarouselItem = React.forwardRef<
   HTMLDivElement,
   React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
   const { orientation } = useCarousel();

   return (
      <div
         ref={ref}
         role="group"
         aria-roledescription="slide"
         className={cn(
            "min-w-0 shrink-0 grow-0 basis-full",
            orientation === "horizontal" ? "pl-4" : "pt-4",
            className,
         )}
         {...props}
      />
   );
});
CarouselItem.displayName = "CarouselItem";

const CarouselPrevious = React.forwardRef<
   HTMLButtonElement,
   React.ComponentProps<typeof Button>
>(({ className, ...props }, ref) => {
   const { scrollPrev, canScrollPrev } = useCarousel();

   return (
      <Button
         ref={ref}
         className={cn(
            "group flex h-10 w-[70px] items-center justify-center rounded-md bg-background-darkSecondary transition-all duration-200 hover:bg-primary",
            className,
         )}
         variant="skew"
         disabled={!canScrollPrev}
         onClick={scrollPrev}
         {...props}
      >
         <LeftArrow2Icon className="h-[12px] w-[23px] fill-white opacity-40 group-hover:opacity-100" />
      </Button>
   );
});
CarouselPrevious.displayName = "CarouselPrevious";

const CarouselNext = React.forwardRef<
   HTMLButtonElement,
   React.ComponentProps<typeof Button>
>(({ className, ...props }, ref) => {
   const { scrollNext, canScrollNext } = useCarousel();

   return (
      <Button
         ref={ref}
         className={cn(
            "group flex h-10 w-[70px] items-center justify-center rounded-md bg-background-darkSecondary transition-all duration-200 hover:bg-primary",
            className,
         )}
         variant="skew"
         disabled={!canScrollNext}
         onClick={scrollNext}
         {...props}
      >
         <RightArrow2Icon className="h-[12px] w-[23px] fill-white opacity-40 group-hover:opacity-100" />
      </Button>
   );
});
CarouselNext.displayName = "CarouselNext";

<Button
   className="group flex h-10 w-[70px] items-center justify-center rounded-md bg-background-darkSecondary transition-all duration-200 hover:bg-primary"
   variant="skew"
>
   <RightArrow2Icon className="h-[12px] w-[23px] fill-white opacity-40 group-hover:opacity-100" />
</Button>;

export {
   type CarouselApi,
   Carousel,
   CarouselContent,
   CarouselItem,
   CarouselPrevious,
   CarouselNext,
};
