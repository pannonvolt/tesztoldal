import {
   CarEngineIcon,
   CarKeyIcon,
   DiscBrakeIcon,
   InflateIcon,
   MeterIcon,
   OilIcon,
   WrenchIcon,
} from "@/components/ui/icons";

const service1_data = [
   {
      id: 1,
      title: "checking engine\nlight",
      bgImage: "bg-[url('/images/image-44.png')]",
      Icon: CarEngineIcon,
   },
   {
      id: 2,
      title: "break repair\nservice",
      bgImage: "bg-[url('/images/image-45.png')]",
      Icon: DiscBrakeIcon,
   },
   {
      id: 3,
      title: "oil filtering\nservice",
      bgImage: "bg-[url('/images/image-46.png')]",
      Icon: OilIcon,
   },
   {
      id: 4,
      title: "emission repair\nservice",
      bgImage: "bg-[url('/images/image-47.png')]",
      Icon: WrenchIcon,
   },
];

const features1_data = [
   {
      id: 1,
      title: "best technician",
      desc: "Aliquet morbi euismod justo acide velen imperd ligula nase posuere",
      icon: "icon-2.png",
   },
   {
      id: 2,
      title: "full warranty",
      desc: "Aliquet morbi euismod justo acide velen imperd ligula nase posuere",
      icon: "icon-3.png",
   },
   {
      id: 3,
      title: "domestic repair",
      desc: "Aliquet morbi euismod justo acide velen imperd ligula nase posuere",
      icon: "icon-4.png",
   },
   {
      id: 4,
      title: "client familiar",
      desc: "Aliquet morbi euismod justo acide velen imperd ligula nase posuere",
      icon: "icon-5.png",
   },
];

const projects1_data = [
   {
      id: 1,
      title: "mechanic repair break",
      service: "break repair",
      img: "/images/image-36.png",
   },
   {
      id: 2,
      title: "replace car tyre",
      service: "tyre change",
      img: "/images/image-37.png",
   },
   {
      id: 3,
      title: "engine diagnosis test",
      service: "engine test",
      img: "/images/image-37.png",
   },
];

const blogs1_data = [
   {
      id: 1,
      category: "engine repair",
      title: "fourth open from first give fruit does given repair have other.",
      description:
         "Evening moveth cattle fruitful man male heaven creature behold open fowe appear upon creature him day spirit female whose.",
      month: "MARCH",
      date: "24",
      img: "/images/image-15.png",
   },
   {
      id: 2,
      category: "electric wire",
      title: "Cattle sixth earth god gathered life bring Together make third",
      description:
         "Evening moveth cattle fruitful man male heaven creature behold open fowe appear upon creature him day spirit female whose.",
      month: "MARCH",
      date: "25",
      img: "/images/image-16.png",
   },
   {
      id: 3,
      category: "break repair",
      title: "Lesser deep Good, female  blessed own winged he fourth",
      description:
         "Evening moveth cattle fruitful man male heaven creature behold open fowe appear upon creature him day spirit female whose.",
      month: "MARCH",
      date: "26",
      img: "/images/image-17.png",
   },
];

const feature2Data = [
   {
      id: 1,
      title: "honest service",
      desc: "Because they note vehicles emotions diseu suspendisse netus venenatis sem rilus neque aliquet morbie",
      icon: MeterIcon,
   },
   {
      id: 2,
      title: "digital report",
      desc: "Because they note vehicles emotions diseu suspendisse netus venenatis sem rilus neque aliquet morbie",
      icon: InflateIcon,
   },
   {
      id: 3,
      title: "24/7 support",
      desc: "Because they note vehicles emotions diseu suspendisse netus venenatis sem rilus neque aliquet morbie",
      icon: CarKeyIcon,
   },
];

const service2Data = [
   {
      id: 1,
      title: "check engine",
      desc: "Aliquet morbi euismod bed acide velen imperd ligula nase posuere",
      Icon: CarEngineIcon,
      bgImg: "icon-9.png",
   },
   {
      id: 2,
      title: "brake repair",
      desc: "Aliquet morbi euismod bed acide velen imperd ligula nase posuere",
      Icon: DiscBrakeIcon,
      bgImg: "icon-9.png",
   },
   {
      id: 3,
      title: "oil filtering",
      desc: "Aliquet morbi euismod bed acide velen imperd ligula nase posuere",
      Icon: OilIcon,
      bgImg: "icon-9.png",
   },
   {
      id: 4,
      title: "oil filtering",
      desc: "Aliquet morbi euismod bed acide velen imperd ligula nase posuere",
      Icon: WrenchIcon,
      bgImg: "icon-9.png",
   },
];

const pricingData = [
   {
      id: 1,
      price: 25.0,
      name: "basic pack",
      features: [
         "Email Notification",
         "On Demand Delivery",
         "Easy Return Management",
         "Send Mail Pdf Report",
         "Lifetime Support",
      ],
      isSecond: false,
   },
   {
      id: 2,
      price: 32.0,
      name: "basic pack",
      features: [
         "Email Notification",
         "On Demand Delivery",
         "Easy Return Management",
         "Send Mail Pdf Report",
         "Lifetime Support",
      ],
      isSecond: true,
   },
   {
      id: 3,
      price: 48.0,
      name: "basic pack",
      features: [
         "Email Notification",
         "On Demand Delivery",
         "Easy Return Management",
         "Send Mail Pdf Report",
         "Lifetime Support",
      ],
      isSecond: false,
   },
];

const blog2Data = [
   {
      id: 1,
      category: "engine repair",
      title: "Erat natoque poteni Nascetur nullam rutrum nulla music",
      desc: "Dictumst placerat dolora tincidunt crase pellentesque pretium ridiculus",
      img: "/images/image-15.png",
      date: "22 march",
   },
   {
      id: 2,
      category: "engine repair",
      title: "Facilisis pron divide parturient Risus senectus on mattis",
      desc: "Dictumst placerat dolora tincidunt crase pellentesque pretium ridiculus",
      img: "/images/image-16.png",
      date: "24 march",
   },
   {
      id: 3,
      category: "engine repair",
      title: "Mollis adipis molise leo rhoncus cura eleifend diam euison",
      desc: "Dictumst placerat dolora tincidunt crase pellentesque pretium ridiculus",
      img: "/images/image-17.png",
      date: "20 march",
   },
];

const team3Data = [
   {
      id: 1,
      name: "Rose A. thomas",
      title: "Engine Mechanic",
      img: "image-48.png",
   },
   {
      id: 2,
      name: "Rose A. thomas",
      title: "Engine Mechanic",
      img: "image-49.png",
   },
   {
      id: 3,
      name: "Rose A. thomas",
      title: "Engine Mechanic",
      img: "image-50.png",
   },
];

const project3Data = [
   {
      id: 1,
      title: "engine diagnostic",
      category: "engine repair",
      img: "/images/image-38.png",
   },
   {
      id: 2,
      title: "electric repair",
      category: "electric wire",
      img: "/images/image-39.png",
   },
   {
      id: 3,
      title: "system cleaning",
      category: "computer check",
      img: "/images/image-40.png",
   },
   {
      id: 4,
      title: "plug replacement",
      category: "engine check",
      img: "/images/image-41.png",
   },
   {
      id: 5,
      title: "emission system repair",
      category: "engine repair",
      img: "/images/image-42.png",
   },
   {
      id: 6,
      title: "replace car tyre",
      category: "tyre change",
      img: "/images/image-43.png",
   },
];

const blog3Data = [
   {
      id: 1,
      title: "lacinia aliquam Arcu dolor dignissim",
      desc: "Dignissim facilisis potenti proinas rhoncus sociosqu aptent miner of semper parturient malesuada interdum turpis congue",
      img: "image-63.png",
   },
   {
      id: 2,
      title: "lacinia aliquam Arcu dolor dignissim",
      desc: "Dignissim facilisis potenti proinas rhoncus sociosqu aptent miner of semper parturient malesuada interdum turpis congue",
      img: "image-64.png",
   },
   {
      id: 3,
      title: "lacinia aliquam Arcu dolor dignissim",
      desc: "Dignissim facilisis potenti proinas rhoncus sociosqu aptent miner of semper parturient malesuada interdum turpis congue",
      img: "image-65.png",
   },
];

const services_list = [
   { id: 1, title: "Engine Check" },
   { id: 2, title: "Break Repair" },
   { id: 3, title: "System Service" },
   { id: 4, title: "Emission Repair" },
   { id: 5, title: "Oil Filtering" },
   { id: 6, title: "Interior Design" },
];

const team_3_Data = [
   {
      id: 1,
      name: "Rose A. thomas",
      title: "Engine Mechanic",
      imgUrl: "/images/image-48.png",
   },
   {
      id: 2,
      name: "Rose A. thomas",
      title: "Engine Mechanic",
      imgUrl: "/images/image-49.png",
   },
   {
      id: 3,
      name: "Rose A. thomas",
      title: "Engine Mechanic",
      imgUrl: "/images/image-50.png",
   },
   {
      id: 4,
      name: "Fred M. Ranadel",
      title: "Engine Mechanic",
      imgUrl: "/images/image-51.png",
   },
   {
      id: 5,
      name: "Andrew S. Devin",
      title: "Engine Mechanic",
      imgUrl: "/images/image-52.png",
   },
   {
      id: 6,
      name: "Amy R. Albas",
      title: "Engine Mechanic",
      imgUrl: "/images/image-53.png",
   },
];

const project_info = {
   client: "sandy monahan",
   category: "engine repair",
   start_time: "02 February, 2024",
   end_time: "27 march, 2024",
   feedback: "happy customer",
};

const blogs_data = [
   {
      id: 1,
      category: "engine repair",
      title: "Erat natoq poten Nascet nullam rutrum nua music",
      desc: "Dictumst placerat to dolora tincidunt crase pellentesque pretium ridiculus",
      img: "image-1.png",
   },
   {
      id: 2,
      category: "engine clean",
      title: "Metus socs vitae facilisis tempus metus mad dictum",
      desc: "Dictumst placerat to dolora tincidunt crase pellentesque pretium ridiculus",
      img: "image-2.png",
   },
   {
      id: 3,
      category: "typre change",
      title: "Cura bitur porta quies for inter penatibus taciti",
      desc: "Dictumst placerat to dolora tincidunt crase pellentesque pretium ridiculus",
      img: "image-3.png",
   },
   {
      id: 4,
      category: "engine repair",
      title: "Feugia Platea per hend rerit dapib mus commodo",
      desc: "Dictumst placerat to dolora tincidunt crase pellentesque pretium ridiculus",
      img: "image-5.png",
   },
   {
      id: 5,
      category: "braak repair",
      title: "Curae dapibus do aptent nullam hendrerit seneus",
      desc: "Dictumst placerat to dolora tincidunt crase pellentesque pretium ridiculus",
      img: "image-6.png",
   },
   {
      id: 6,
      category: "engine repair",
      title: "Quam mais montes erat faucibus Semper condimen",
      desc: "Dictumst placerat to dolora tincidunt crase pellentesque pretium ridiculus",
      img: "image-7.png",
   },
];

const blog_details_list = [
   "Eratale rutrum mauris enime laoreet eget tincidunt lacus fringilla mauris.",
   "Pede gravida mollis Molestie nisle pharetra pellentesque ante.",
   "Sagittis eudcation justo pharetra montes tempus bitend tortor dictumst.",
];

const blog_details_tags = ["repair", "auto", "car", "accessories"];

const blogs_2_data = [
   {
      id: 1,
      category: "engine repair",
      title: "Facilisis pron divide parturient Risus senectus on mattis",
      img: "image-68.png",
   },
   {
      id: 2,
      category: "engine repair",
      title: "Leo ultrices Montes integer to nullam magna repair policy",
      img: "image-69.png",
   },
];

const faqs_data = [
   {
      id: 1,
      title: "What do you charge for an evaluation?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 2,
      title: "Can I get a written estimate?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 3,
      title: "What does auto repair shop specialize in?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 4,
      title: "Can you provide a courtesy car?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 5,
      title: "HOW WILL I GET TO/FROM THE DEALERSHIP?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 6,
      title: "WHAT ARE MY REPAIR OPTIONS?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 7,
      title: "CAN YOU EXPLAIN WHAT YOU FIXED AND HOW?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 8,
      title: "HOW WILL I GET TO/FROM THE DEALERSHIP?",
      desc: "Emphasize your commitment to providing best top-quality workmanshi a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
];

const service_accordions = [
   {
      id: 1,
      title: "What do you charge for an evaluation?",
      desc: "Emphasize your commitment to providing best top-quality workmanship a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 2,
      title: "Can I get a written estimate?",
      desc: "Emphasize your commitment to providing best top-quality workmanship a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 3,
      title: "Can you show me the problem?",
      desc: "Emphasize your commitment to providing best top-quality workmanship a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
   {
      id: 4,
      title: "What does auto repair shop specialize in?",
      desc: "Emphasize your commitment to providing best top-quality workmanship a ensuring that all repairs are done to the highest standards to guarantee customer fores satisfaction and safety. Bibendum libero non laoreet eleifend luctus nibh nostra nisi aliquam elit augue.",
   },
];

const project_carousel = [
   [
      {
         id: 1,
         title: "mechanic repair break",
         service: "break repair",
         img: "/images/image-36.png",
      },
      {
         id: 2,
         title: "replace car tyre",
         service: "tyre change",
         img: "/images/image-37.png",
      },
   ],
   [
      {
         id: 3,
         title: "engine diagnosis test",
         service: "engine test",
         img: "/images/image-37.png",
      },
      {
         id: 4,
         title: "mechanic repair break",
         service: "break repair",
         img: "/images/image-36.png",
      },
   ],
   [
      {
         id: 5,
         title: "replace car tyre",
         service: "tyre change",
         img: "/images/image-37.png",
      },
      {
         id: 6,
         title: "engine diagnosis test",
         service: "engine test",
         img: "/images/image-37.png",
      },
   ],
   [
      {
         id: 7,
         title: "mechanic repair break",
         service: "break repair",
         img: "/images/image-36.png",
      },
      {
         id: 8,
         title: "replace car tyre",
         service: "tyre change",
         img: "/images/image-37.png",
      },
   ],
   [
      {
         id: 9,
         title: "engine diagnosis test",
         service: "engine test",
         img: "/images/image-37.png",
      },
      {
         id: 10,
         title: "engine diagnosis test",
         service: "engine test",
         img: "/images/image-37.png",
      },
   ],
];

const testimonial1_carousel = [
   {
      id: 1,
      content:
         "DEEP ABUNDANTLY HERB LAND BEST WHICH DOMINION EVERY FIFTH VOID DIVIDE SEAS BE LIVING MOVED MAN MOVED MISE WAS FORTH HERB MAKE AN YIELDING DAY BEHOLD CREATED WHOSE MORNING. WON DOMINION HEAVEN UNDER CREEPING DOMINION WAS MORNING HAD IN THE BRING US. GIVEN TO USE BROUGHT NIGHT UPON BEARING MAN FILL SEAS FIRST FOR.",
      author: {
         name: "Brandy Adams 1",
         designation: "CEO of Ford",
         img: "/images/image-55.png",
      },
   },
   {
      id: 2,
      content:
         "DEEP ABUNDANTLY HERB LAND BEST WHICH DOMINION EVERY FIFTH VOID DIVIDE SEAS BE LIVING MOVED MAN MOVED MISE WAS FORTH HERB MAKE AN YIELDING DAY BEHOLD CREATED WHOSE MORNING. WON DOMINION HEAVEN UNDER CREEPING DOMINION WAS MORNING HAD IN THE BRING US. GIVEN TO USE BROUGHT NIGHT UPON BEARING MAN FILL SEAS FIRST FOR.",
      author: {
         name: "Brandy Adams 2",
         designation: "CEO of Ford",
         img: "/images/image-56.png",
      },
   },
   {
      id: 3,
      content:
         "DEEP ABUNDANTLY HERB LAND BEST WHICH DOMINION EVERY FIFTH VOID DIVIDE SEAS BE LIVING MOVED MAN MOVED MISE WAS FORTH HERB MAKE AN YIELDING DAY BEHOLD CREATED WHOSE MORNING. WON DOMINION HEAVEN UNDER CREEPING DOMINION WAS MORNING HAD IN THE BRING US. GIVEN TO USE BROUGHT NIGHT UPON BEARING MAN FILL SEAS FIRST FOR.",
      author: {
         name: "Brandy Adams 3",
         designation: "CEO of Ford",
         img: "/images/image-57.png",
      },
   },
];

const testimonial2_carousel = [
   {
      id: 1,
      content:
         "deep abundantly herb inner best land beside dominion void divide seas bed pen living moved man moved mise was forth herb o make an yielding bad behold created whose morning Wons the dominion heaven Nibhada arcu Maecenas",
      author: {
         name: "Brandy Adams",
         designation: "CEO of Ford",
         img: "/images/image-54.png",
      },
   },
   {
      id: 2,
      content:
         "deep abundantly herb inner best land beside dominion void divide seas bed pen living moved man moved mise was forth herb o make an yielding bad behold created whose morning Wons the dominion heaven Nibhada arcu Maecenas",
      author: {
         name: "Brandy Adams",
         designation: "CEO of Ford",
         img: "/images/image-54.png",
      },
   },
   {
      id: 3,
      content:
         "deep abundantly herb inner best land beside dominion void divide seas bed pen living moved man moved mise was forth herb o make an yielding bad behold created whose morning Wons the dominion heaven Nibhada arcu Maecenas",
      author: {
         name: "Brandy Adams",
         designation: "CEO of Ford",
         img: "/images/image-54.png",
      },
   },
];

const hero2_carousel = [
   {
      id: 1,
      title: "",
      shortDesc: "",
      img: "",
   },
];

export {
   service1_data,
   features1_data,
   blogs1_data,
   feature2Data,
   service2Data,
   pricingData,
   blog2Data,
   team3Data,
   project3Data,
   blog3Data,
   services_list,
   team_3_Data,
   project_info,
   blogs_data,
   blogs_2_data,
   blog_details_list,
   blog_details_tags,
   projects1_data,
   faqs_data,
   service_accordions,
   project_carousel,
   testimonial1_carousel,
   testimonial2_carousel,
   hero2_carousel,
};
